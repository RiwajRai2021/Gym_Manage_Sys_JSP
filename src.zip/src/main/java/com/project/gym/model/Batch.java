package com.project.gym.model;

public class Batch {

	private int bid; 
	private String batch_name; 
	private String timeOfDay; 
		
	
	public Batch() {
		
	}


	public int getBid() {
		return bid;
	}


	public void setBid(int bid) {
		this.bid = bid;
	}


	public String getBatch_name() {
		return batch_name;
	}


	public void setBatch_name(String batch_name) {
		this.batch_name = batch_name;
	}


	public String getTimeOfDay() {
		return timeOfDay;
	}


	public void setTimeOfDay(String timeOfDay) {
		this.timeOfDay = timeOfDay;
	}
	
	
	
	

}
